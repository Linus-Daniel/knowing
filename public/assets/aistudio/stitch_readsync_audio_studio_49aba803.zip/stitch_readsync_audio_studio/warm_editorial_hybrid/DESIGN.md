---
name: Warm Editorial Hybrid
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#554336'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#887364'
  outline-variant: '#dbc2b0'
  surface-tint: '#904d00'
  primary: '#8d4b00'
  on-primary: '#ffffff'
  primary-container: '#b15f00'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb77d'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#984300'
  on-tertiary: '#ffffff'
  tertiary-container: '#bb5810'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcc3'
  primary-fixed-dim: '#ffb77d'
  on-primary-fixed: '#2f1500'
  on-primary-fixed-variant: '#6e3900'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb68e'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#763300'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display-hero:
    fontFamily: Literata
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Literata
    fontSize: 34px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Literata
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Literata
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Literata
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-reading-lg:
    fontFamily: Literata
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: -0.005em
  body-reading-md:
    fontFamily: Literata
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 29px
    letterSpacing: 0em
  body-ui:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  label-md:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  caption:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  audio-timestamp:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a quiet, content-first environment engineered for deep literary immersion, synchronized audio playback, and active document annotation. By synthesizing the typography-driven polish of Apple Books, the kinetic media ergonomics of Audible, and the structured minimalism of Notion, the system strikes a delicate balance between focused utility and artisanal warmth.

The aesthetic philosophy centers on **Warm Modern Editorial**:
- **Distraction-Free Focus:** Application chrome recedes into the perimeter, surfacing content as the primary visual actor. Controls emerge on intent and dissolve during active reading or listening states.
- **Atmospheric Warmth:** Rather than cold clinical grays, the canvas relies on rich slate undertones and parchment-inspired warmth, mitigating visual fatigue during extended sessions.
- **Synchronous Harmony:** Dynamic typography and luminous sentence-level read-along accents establish fluid, tactile connections between the spoken voice and the written word.

## Colors

The palette is anchored by glowing amber resonances set against balanced, high-legibility slate neutrals. Color is deployed conservatively to preserve cognitive bandwidth, reserving energetic pigment strictly for playback states, active sentence trackers, and focused navigation targets.

### Theme Modes & Canvas Roles

#### 1. Light Mode (Crisp Paper)
- **Base Canvas (`surface-base`):** `#FAFAF9` (warm stone alabaster, preventing glare).
- **Elevated Canvas (`surface-raised`):** `#FFFFFF` (crisp card and floating dock fill).
- **Sunken Canvas (`surface-sunken`):** `#F3F4F6` (trackers, scrubber troughs, sidebar rails).
- **Text Primary:** `#0F172A` (deep slate ink).
- **Text Secondary:** `#475569` (mid-slate muted).
- **Borders & Dividers:** `#E2E8F0` (soft structural borders).

#### 2. Sepia Mode (Warm Parchment)
- **Base Canvas:** `#FBF7EE` (classic cream book stock).
- **Elevated Canvas:** `#F4EEDB` (layered cards and dialogs).
- **Text Primary:** `#292524` (deep espresso ink).
- **Text Secondary:** `#57534E` (warm umber muted).
- **Borders & Dividers:** `#E7DEC8` (muted antique hairline).

#### 3. Dark / OLED Mode (Obsidian Slate)
- **Base Canvas (`surface-base`):** `#090D16` (near-OLED deep midnight slate).
- **Elevated Canvas (`surface-raised`):** `#131B2E` (tinted container slate).
- **Sunken Canvas (`surface-sunken`):** `#0F172A` (inset tracks and badges).
- **Text Primary:** `#F8FAFC` (pure readability highlight).
- **Text Secondary:** `#94A3B8` (soft reflective slate).
- **Borders & Dividers:** `rgba(255, 255, 255, 0.08)` (subtle ambient trace).

### Karaoke & Read-Along Semantics
- **Active Sentence Highlight:** `rgba(245, 158, 11, 0.16)` in light/sepia modes; `rgba(245, 158, 11, 0.22)` in dark mode with a 2px left border strip in `#F59E0B`.
- **Word-Level Progress Scrub:** Soft animated linear fill using `#D97706` overlaid in text selection tint.

## Typography

The typographic engine bifurcates into two distinct domains: **Editorial Immersion** and **Functional Chrome**.

- **Editorial Reading Pane (`Literata`):** Designed specifically for continuous reading on digital displays. Its organic proportions, diagonal stress, and relaxed metrics recreate the warmth of physical letterpress. Used across narrative text, document paragraphs, and chapter headlines.
- **Application Shell & Player Controls (`Manrope`):** A modern, geometric grotesque with open apertures and clean terminals. It provides rapid scanning for timestamps, chapter lists, settings, and player states without fighting the literary text.

Reading panes must support dynamic reader controls:
- Users can toggle body font between `Literata` and `Manrope`.
- Paragraph line heights default to an airy 1.7x multiplier to accommodate real-time line highlighting without vertical clipping.

## Layout & Spacing

The layout is built upon a dual-pane hybrid grid that accommodates synchronized dual-state interactions: document canvas on one axis, audio telemetry and chapter metadata on the other.

### Layout Grid & Viewport Breakpoints
- **Mobile (`< 768px`):** Single-column stacked fluid layout. Outer margins fixed to `margin-sm` (`1rem`). The reading stream occupies 100% width with the floating audio dock anchored to the bottom safe area.
- **Tablet (`768px – 1024px`):** Single column with optional slide-over panel. Reading pane constrained to a comfortable maximum reading measure of `680px` centered within `margin` (`1.5rem`).
- **Desktop (`> 1024px`):** 12-column split-view grid with `gutter` (`1.5rem`) and `margin-lg` (`3rem`):
  - **Left / Navigation Rail:** 2 columns (collapsible).
  - **Center / Reading Stage:** 7 columns (optimal line length capped at `72ch`).
  - **Right / Inspector & Transcript:** 3 columns for active notes, glossary, and audio scrubbing controls.

### Spacing Cadence
Component internals follow a disciplined 4px/8px incremental rhythm. Spacing between distinct editorial sections scales up to `space-xl` (`2.5rem`) to create intentional resting zones between chapters and headers.

## Elevation & Depth

Visual hierarchy employs **Tonal Layering** accompanied by **Subtle Glassmorphism** and ultra-diffused atmospheric shadows. Avoid stark drop shadows and thick, heavy boundaries.

### Depth Hierarchy
1. **Level 0 (Base Canvas):** Flat base surface with zero elevation.
2. **Level 1 (Cards & Book Grid Tiles):** Rests on `surface-raised` accompanied by a hairline border (`1px solid rgba(226, 232, 240, 0.8)` in light, `1px solid rgba(255, 255, 255, 0.06)` in dark) and an ambient shadow: `0 2px 8px -2px rgba(15, 23, 42, 0.04)`.
3. **Level 2 (Audio Mini-Player Dock & Toolbars):** Floating elements detached from screen borders. Employs frosted glass (`backdrop-filter: blur(16px); background: rgba(255, 255, 255, 0.85)` in light, `rgba(19, 27, 46, 0.85)` in dark) paired with a dual shadow: `0 4px 20px -4px rgba(15, 23, 42, 0.1), 0 1px 2px rgba(15, 23, 42, 0.05)`.
4. **Level 3 (Modal Sheets, Audio Scrub Drawers & Menus):** High-elevation overlays with a rich backdrop occlusion (`rgba(15, 23, 42, 0.4)`) and a deep diffused shadow: `0 16px 40px -8px rgba(15, 23, 42, 0.2)`.

## Shapes

The geometric signature uses comfortable, modern radii that feel tactile yet structured.

- **Base Radius (`0.5rem` / `8px`):** Applied to buttons, input fields, chip tags, and dropdown items.
- **Large Radius (`1rem` / `16px`):** Applied to content cards, book jacket cards, and audio scrubber panels.
- **Extra Large Radius (`1.5rem` / `24px`):** Applied to floating audio mini-player docks and modal sheets.
- **Pill Shape (`9999px`):** Applied to playback control buttons, speed selector badges, and scrub grabbers.

## Components

### 1. Synchronized Read-Along Text Block
- **Resting Sentence:** Standard reading typography with high line-height (`34px`). Smooth font rendering enabled.
- **Active Karaoke Sentence:** Enclosed in a softly radiused background (`rounded-md`, 4px padding around boundary) tinted with `rgba(245, 158, 11, 0.16)`. A vertical marker (`2px solid #F59E0B`) accents the leading margin. Transitions between sentences use a `250ms ease-out` color fade.
- **Word Progress (Optional micro-sync):** Spoken words animate with a bold weight transition and a subtle warm amber glow.

### 2. Audio Mini-Player Dock
- **Architecture:** Floating horizontal bar pinned `1rem` above viewport bottom, max-width `720px`, centered.
- **Surface:** Frosted glass with Level 2 elevation and `1.5rem` corner radius.
- **Internal Elements:**
  - Thumbnail jacket art (`44x44px`, `rounded-md`).
  - Metadata stack: Title (`label-md`) and Narrator/Author (`caption`, muted slate).
  - Central transport: 15s skip back, Play/Pause circle button (`40x40px`, solid primary amber fill `#D97706` with white icon), 15s skip forward.
  - Interactive scrub line: 3px height resting, expands to 6px on hover, warm amber progress fill with slate trough.
  - Speed badge: Pill button displaying current speed (`1.0x`, `1.25x`, `1.5x`).

### 3. Buttons & Action Elements
- **Primary:** Solid `#D97706` background, crisp white label, `0.5rem` radius, subtle hover scale (`scale(1.02)`), active state `#B45309`.
- **Secondary / Ghost:** Transparent fill, `1px solid rgba(226, 232, 240, 1)` (light) or `rgba(255, 255, 255, 0.1)` (dark), interactive hover fills with `surface-sunken`.
- **Icon Action Buttons:** `36x36px` touch target, fully circular or `rounded-md`, muted icon tint transitioning to amber on hover.

### 4. Chips & Progress Badges
- Compact pills using `label-sm`.
- Status indicators (e.g., "Narrated by Author", "Whispersync Active") feature a `6px` glowing dot indicator in `#F59E0B` alongside uppercase tracking text.

### 5. Cards (Book & Document Tiles)
- Card bodies leverage `surface-raised` with `1rem` radius and a `1px` low-contrast border.
- Cover art maintains a classic `1:1.48` book aspect ratio with an inner `0.5rem` radius.
- Includes a bottom-aligned mini progress bar displaying synchronized read/listen percentage.

### 6. Input Fields & Search Bars
- Inset canvas appearance (`surface-sunken`) with `0.5rem` radius and no drop shadow.
- Border shifts from subtle neutral to an intentional 1.5px `#D97706` ring on active focus.
- Monospace or clean sans placeholder text, accompanied by keyboard shortcut badges (`⌘K`).

### 7. Annotation & Note Sliders
- Minimalist margin callouts: small amber pin anchors inline with text that expand into floating cards displaying user notes, audio bookmarks, or definitions.